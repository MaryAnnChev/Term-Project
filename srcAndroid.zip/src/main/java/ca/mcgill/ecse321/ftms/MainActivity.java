package ca.mcgill.ecse321.ftms;

import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;


import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;

import java.io.File;
import java.sql.Date;
import java.sql.Time;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import ca.mcgill.ecse321.FTMS.application.FTMS;
import ca.mcgill.ecse321.FTMS.controller.FTMSController;
import ca.mcgill.ecse321.FTMS.controller.InvalidInputException;
import ca.mcgill.ecse321.FTMS.model.Employee;
import ca.mcgill.ecse321.FTMS.model.Schedule;
import ca.mcgill.ecse321.FTMS.model.ScheduleRegistration;
import ca.mcgill.ecse321.FTMS.model.StaffManager;
import ca.mcgill.ecse321.FTMS.persistence.PersistenceFTMS;
import ca.mcgill.ecse321.FTMS.persistence.PersistenceXStream;


public class MainActivity extends AppCompatActivity {


    HashMap<Integer, Employee> employees;
    HashMap<Integer, Schedule> schedules;
    StaffManager sm;

 /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        PersistenceFTMS.setFilename(getFilesDir().getAbsolutePath() + "/ftms.xml");
        PersistenceFTMS.loadFTMSModel();
        System.out.println(getFilesDir().getAbsoluteFile() + "ftms.xml");
        sm = StaffManager.getInstance();
        refreshData();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    private void refreshData() {
        TextView tv;
        TextView tv1;
        TextView tv2;
        TextView tv3;

        tv = (TextView) findViewById(R.id.newemployee_name);
        tv2 = (TextView) findViewById(R.id.newrole_name);

        tv3 = (TextView) findViewById(R.id.newhour);

        tv1 = (TextView) findViewById(R.id.newschedule_name);
        tv1.setText("");
        tv.setText("");
        tv2.setText("");
        tv3.setText("");
        StaffManager sm = StaffManager.getInstance();

        // Initialize the data in the employee spinner
        Spinner spinner1 = (Spinner) findViewById(R.id.employeespinner);
        ArrayAdapter<CharSequence> employeeAdapter = new
                ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item);
        employeeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        this.employees = new HashMap<Integer, Employee>();
        int i = 0;
        for (Iterator<Employee> employees = sm.getEmployees().iterator();
             employees.hasNext(); i++) {
            Employee e = employees.next();
            employeeAdapter.add(e.getStaffName());
            this.employees.put(i, e);
        }
        spinner1.setAdapter(employeeAdapter);

        // Initialize the data in the schedule spinner
        Spinner spinner2 = (Spinner) findViewById(R.id.schedulespinner);
        ArrayAdapter<CharSequence> scheduleAdapter = new
                ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item);
        scheduleAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        this.schedules = new HashMap<Integer, Schedule>();
        int j = 0;
        for (Iterator<Schedule> schedules = sm.getSchedules().iterator();
             schedules.hasNext(); j++) {
            Schedule s = schedules.next();
            scheduleAdapter.add(s.getWeekday());
            this.schedules.put(j, s);
        }
        spinner2.setAdapter(scheduleAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void addEmployee(View v) throws InvalidInputException {
        TextView tv = (TextView) findViewById(R.id.newemployee_name);
        TextView tv1 = (TextView) findViewById(R.id.newrole_name);
        TextView tv2 = (TextView) findViewById(R.id.newhour);
        TextView error = (TextView) findViewById(R.id.errorMessage);

        FTMSController erc = new FTMSController();
        try {
            erc.createEmployee(tv.getText().toString(), tv1.getText().toString(), Integer.parseInt(String.valueOf(tv2.getText())));
        } catch (InvalidInputException e) {
            error.setText(e.getMessage());
        }
        refreshData();
    }

    public void addSchedule(View v) throws InvalidInputException {
        TextView tv = (TextView) findViewById(R.id.newschedule_name);
        TextView tv1 = (TextView) findViewById(R.id.newschedule_date);
        TextView tv2 = (TextView) findViewById(R.id.newschedule_starttime);
        TextView tv3 = (TextView) findViewById(R.id.newschedule_endtime);
        TextView error = (TextView) findViewById(R.id.errorMessage);

        Bundle startTimeBundle = getTimeFromLabel(tv2.getText().toString());
        Time startTime = new Time(startTimeBundle.getInt("hour") * 3600000 + startTimeBundle.getInt("minute") * 60000);
        Bundle endTimeBundle = getTimeFromLabel(tv3.getText().toString());
        Time endTime = new Time(endTimeBundle.getInt("hour") * 3600000 + endTimeBundle.getInt("minute") * 60000);
        Bundle scheduleDateBundle = getDateFromLabel(tv1.getText().toString());
        Calendar c = Calendar.getInstance();
        c.set(scheduleDateBundle.getInt("year"), scheduleDateBundle.getInt("month"), scheduleDateBundle.getInt("day"));
        Date scheduleDate = new Date(c.getTime().getTime());

        FTMSController erc = new FTMSController();
        try {
            erc.createSchedule(tv.getText().toString(), scheduleDate, startTime, endTime);
        } catch (InvalidInputException e) {
            error.setText(e.getMessage());
        }

        refreshData();

    }

    public void register(View v) throws InvalidInputException {

        TextView error = (TextView) findViewById(R.id.errorMessage);
        StaffManager sm = StaffManager.getInstance();
        Spinner scheduleSpinner = (Spinner) findViewById(R.id.schedulespinner);
        Schedule schedule = this.schedules.get(scheduleSpinner.getSelectedItemPosition());
        Spinner employeeSpinner = (Spinner) findViewById(R.id.employeespinner);
        Employee employee = this.employees.get(employeeSpinner.getSelectedItemPosition());

        FTMSController erc = new FTMSController();
        try {
            erc.scheduleRegister(employee, schedule);
        } catch (InvalidInputException e) {
            error.setText(e.getMessage());
        }

        refreshData();
    }


    public void showDatePickerDialog(View v) {
        TextView tf = (TextView) v;
        Bundle args = getDateFromLabel(tf.getText());
        args.putInt("id", v.getId());
        DatePickerFragment newFragment = new DatePickerFragment();
        newFragment.setArguments(args);
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void showTimePickerDialog(View v) {
        TextView tf = (TextView) v;
        Bundle args = getTimeFromLabel(tf.getText());
        args.putInt("id", v.getId());
        TimePickerFragment newFragment = new TimePickerFragment();
        newFragment.setArguments(args);
        newFragment.show(getSupportFragmentManager(), "timePicker");
    }

    private Bundle getTimeFromLabel(CharSequence text) {
        Bundle rtn = new Bundle();
        String comps[] = text.toString().split(":");
        int hour = 12;
        int minute = 0;
        if (comps.length == 2) {
            hour = Integer.parseInt(comps[0]);
            minute = Integer.parseInt(comps[1]);
        }
        rtn.putInt("hour", hour);
        rtn.putInt("minute", minute);
        return rtn;
    }

    private Bundle getDateFromLabel(CharSequence text) {
        Bundle rtn = new Bundle();
        String comps[] = text.toString().split("-");
        int day = 1;
        int month = 1;
        int year = 1;
        if (comps.length == 3) {
            day = Integer.parseInt(comps[0]);
            month = Integer.parseInt(comps[1]);
            year = Integer.parseInt(comps[2]);
        }
        rtn.putInt("day", day);
        rtn.putInt("month", month - 1);
        rtn.putInt("year", year);
        return rtn;
    }

    public void setTime(int id, int h, int m) {
        TextView tv = (TextView) findViewById(id);
        tv.setText(String.format("%02d:%02d", h, m));
    }

    public void setDate(int id, int d, int m, int y) {
        TextView tv = (TextView) findViewById(id);
        tv.setText(String.format("%02d-%02d-%04d", d, m + 1, y));
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public Action getIndexApiAction() {
        Thing object = new Thing.Builder()
                .setName("Main Page") // TODO: Define a title for the content shown.
                // TODO: Make sure this auto-generated URL is correct.
                .setUrl(Uri.parse("http://[ENTER-YOUR-URL-HERE]"))
                .build();
        return new Action.Builder(Action.TYPE_VIEW)
                .setObject(object)
                .setActionStatus(Action.STATUS_TYPE_COMPLETED)
                .build();
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        AppIndex.AppIndexApi.start(client, getIndexApiAction());
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        AppIndex.AppIndexApi.end(client, getIndexApiAction());
        client.disconnect();
    }
}
